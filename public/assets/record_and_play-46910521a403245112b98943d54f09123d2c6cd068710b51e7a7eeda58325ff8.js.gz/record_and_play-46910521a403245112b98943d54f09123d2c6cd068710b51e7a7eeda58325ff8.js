function RecordAndPlay(tag){
    alert("aaaaaa");
}
;
